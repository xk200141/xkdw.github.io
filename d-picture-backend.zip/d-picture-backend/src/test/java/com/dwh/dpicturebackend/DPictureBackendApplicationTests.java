package com.dwh.dpicturebackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DPictureBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
